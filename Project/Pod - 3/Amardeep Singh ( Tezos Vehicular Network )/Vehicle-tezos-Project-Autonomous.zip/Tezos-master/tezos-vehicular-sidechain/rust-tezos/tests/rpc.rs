#[test]
fn test_get_balance() {
    assert_eq!(add(1, 2), 3);
}
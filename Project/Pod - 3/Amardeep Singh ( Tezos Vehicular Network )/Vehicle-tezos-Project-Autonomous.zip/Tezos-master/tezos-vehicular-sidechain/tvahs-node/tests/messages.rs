#[test]
fn test_send_message() {
    assert!(false); // TODO
}